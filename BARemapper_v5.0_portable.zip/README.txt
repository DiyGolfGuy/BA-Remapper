BA Remapper v5.0 - portable
BA Custom Products - bacustomproducts.com

1. Move BARemapper.exe to a permanent folder, for example:
   Documents\BA Custom Products\Remapper\
2. Double-click to run. If SmartScreen appears: More info -> Run anyway.
3. Pick the "Basic Secondary" profile, press Turn ON, and play.

Prefer a normal installed program with an uninstaller? Use
BARemapper_Setup from the same download page instead.

Full documentation: see the README on the GitHub repository.
